<?php

include_once 'conexao.php';

$nome_completo = $_POST['nome_completo']

?>
    <table border="1">
        <tr>
            <th>Nome</th>
            <th>Celular</th>
            <th>Contato</th>
            <th>Rua</th>
            <th>Complemento</th>
            <th>Bairro</th>
            <th>Cidade</th>
            <th>UF</th>
            <th>CEP</th>
        </tr>
    <?php
        $consulta_cliente = $conexao -> query("SELECT * FROM cliente LEFT JOIN endereco 
        ON endereco_id_endereco = id_endereco WHERE nome_completo = $nome_completo");


        while($lista = $consulta_cliente->fetch(PDO::FETCH_ASSOC)){
    ?>
        <tr>
            <td><?php echo $lista["nome_completo"]; ?></td>
            <td><?php echo $lista["telefone_celular"]; ?></td>
            <td><?php echo $lista["telefone_contato"]; ?></td>
            <td><?php echo $lista["rua"]; ?></td>
            <td><?php echo $lista["complemento"]; ?></td>
            <td><?php echo $lista["bairro"]; ?></td>
            <td><?php echo $lista["cidade"]; ?></td>
            <td><?php echo $lista["uf"]; ?></td>
            <td><?php echo $lista["cep"]; ?></td>
        </tr> 
    <?php 
    }
    ?>   
    </table>
    
